Steps to setup and run application
1.) create a database called todo
2.) In todo database, create a table called tasks

run your application. Get more tutorials at codewithawa.com
Thanks